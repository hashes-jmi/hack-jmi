package com.example.mkmnim.socialize.Models

/**
 * Created by nimish on 22/3/18.
 */
class Message constructor(var message:String,var sender:String)
