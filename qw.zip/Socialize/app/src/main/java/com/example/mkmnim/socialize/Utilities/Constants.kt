package com.example.mkmnim.socialize.Utilities

var HOTSPOT_STATE_CHANGE = "HOTSPOT_STATE_CHANGE"
var WIFI_STATE_CHANGE = "WIFI_STATE_CHANGE"
var DISCOVER_CLIENTS = true
var HOTSPOT_ON = false
var WIFI_ON= false
var UNIQUE_CLIENTS_SET= mapOf<String,String>()